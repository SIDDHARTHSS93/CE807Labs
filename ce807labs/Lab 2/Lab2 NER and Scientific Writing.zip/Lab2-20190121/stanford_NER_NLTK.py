import nltk

from nltk.tag import StanfordNERTagger

st = StanfordNERTagger('english.all.3class.distsim.crf.ser.gz', './stanford-ner.jar') 

result=st.tag('Prime Minister Theresa May travelled to Washington in 2017'.split()) 

print(result)

